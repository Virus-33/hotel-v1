﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelLib_v1._0
{
    public class Reception
    {
        public List<Room> Rooms
        {
            get;
            private set;
        }

        public Reception(string path)
        {
            Rooms = FileWorks.GetRooms(path);
        }

        public int BookByNum(int num)
        {
            foreach (Room room in Rooms)
            {
                if (room.Num == num)
                {
                    if (CheckRoom(Rooms, num))
                    {
                        room.Book();
                        return 1;
                    } else
                    {
                        return 0;
                    }
                }
            }
            return 0;
        }

        bool CheckRoom(List<Room> rooms, int num)
        {
            bool res = false;

            foreach (Room room in rooms)
            {
                if (room.Num == num)
                {
                    if (room.status == 0)
                    {
                        res = true;
                        break;
                    }
                }
            }

            return res;
        }

        public int Phone(long a)
        {
            if (!Checkphone(a))
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        bool Checkphone(long inputs)
        {
            return inputs.ToString().Length == 11;
        }
    }
}
