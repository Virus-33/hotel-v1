﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelLib_v1._0
{
    public class Hotel
    {
        string J_Path;
        string Bd_path;
        private Reception Re;
        private OrderList J;

        

        public Hotel(string path, string a_path)
        {
            Bd_path = path;
            J_Path = a_path;
            J = new();
            Re = new(Bd_path);
        }

        public int Order(string h)
        {
            if (IsNum(h))
            {
                if (Re.BookByNum(int.Parse(h)) == 1)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }

        public void NewOrder(int rn, long phone)
        {
            J.orders.Add(new Order(phone, rn));
        }

        public List<Order> GO()
        {
            return J.orders;
        }

        public int Phone(string s)
        {
            long a;
            if (IsNum(s, out a))
            {
                return Re.Phone(a);
            } else
            {
                return 0;
            }
        }

        public List<Room> GR()
        {
            return Re.Rooms;
        }

        public void DO()
        {
            J.orders.Clear();
        }

        public void ReadJ()
        {
            J.Read(J_Path);
        }

        bool IsNum(string a)
        {
            return int.TryParse(a, out _);
        }

        bool IsNum(string a, out long r)
        {
            return long.TryParse(a, out r);
        }
    }
}
