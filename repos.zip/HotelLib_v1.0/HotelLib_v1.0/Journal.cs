﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//

namespace HotelLib_v1._0
{
    public class OrderList
    {
        public List<Order> orders
        {
            get;
            private set;
        }

        public void Read(string path)
        {
            FileWorks.RJ(path);
        }
    }
}
