﻿using System;
using System.IO;
using HotelLib_v1._0;
using System.Collections.Generic;

//TODO: Complete selection 4

namespace Hotel_v2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            if (args.Length == 2 && FileWorks.CheckFile(args[0]) && FileWorks.CheckFile(args[1]))
            {
                Hotel H = new(args[0], args[1]);
                char key;
                bool c = true;
                MessageBlock.MainSCR();
                while (c)
                {
                    while (true)
                    {
                        key = Inputs.GetChar();
                        if ('1' <= key && key <= '4')
                        {
                            break;
                        }
                    }
                    int respond;
                    switch (key)
                    {
                        case '1':
                            MessageBlock.ShowRooms(H.GR());
                            break;
                        case '2':
                            MessageBlock.BookingNum(H.GR());
                            string h = Inputs.GetNum();
                            respond = H.Order(h);
                            if (respond == 0)
                            {
                                MessageBlock.RE();
                            }
                            else
                            {
                                while (true)
                                {
                                    MessageBlock.Phone1();
                                    string phone = Inputs.GetNum();
                                    respond = H.Phone(phone);
                                    if (respond == 0)
                                    {
                                        MessageBlock.PhoneE();
                                    }
                                    else
                                    {
                                        MessageBlock.Phone2();
                                        H.NewOrder(int.Parse(h), long.Parse(phone));
                                        FileWorks.WJ(args[1], H.GO());
                                        H.DO();
                                        break;
                                    }
                                }
                            }
                            break;
                        case '3':
                            while (true)
                            {
                                MessageBlock.PB();
                                string Gogi = Inputs.GetNum();
                                respond = H.Phone(Gogi);
                                if (respond == 0)
                                {
                                    MessageBlock.PhoneE();
                                }
                                else
                                {
                                    while (true)
                                    {

                                    }
                                }
                            }
                            break;
                        case '4':
                            c = false;
                            break;
                    }
                }

            }
            else
            {
                MessageBlock.FE();
                Console.ReadKey(true);
            }
        }
    }
}
